from collections import defaultdict
from posixpath import split
import torch, sys, struct, time
from torch_geometric.utils import coalesce
from torch_geometric.data import Data
from datetime import datetime
import numpy as np

fin = open("electronics.csv", "r")
interactions = fin.readlines()
id_map, id_count = {}, 0
edge_index = []
targets = []
targets_gender = []
streamers = []
"max time 1538366400"
interactions = interactions[1:]
times = defaultdict(int)

init = 1420123460
day = 86400
end = init + 365*day
init += 327*day
items = set()
male_users = set()
female_users = set()

for i in range(len(interactions)):
    inter = interactions[i].replace("\n", "")
    inter = inter.split(",")
    item_id = inter[0]
    user_id = inter[1]
    times[inter[3][:4]] += 1
    date = datetime.strptime(inter[3], '%Y-%m-%d' )
    date = (time.mktime(date.timetuple()))
    if (inter[4] == "Male" or inter[4] == "Female") and (date > init) and (date < end):
        if user_id not in id_map:
            id_map[user_id] = id_count
            id_count += 1
            if inter[4] == "Male":
                male_users.add(id_map[user_id])
            else:
                female_users.add(id_map[user_id])
        if item_id not in id_map:
            id_map[item_id] = id_count
            id_count += 1
            items.add(id_map[item_id])
        if date > end - (7*day):
            targets.append( ( id_map[user_id], id_map[item_id] ) )
            targets_gender.append( inter[4] )
        else:
            edge_index.append( ( id_map[user_id], id_map[item_id] ) )
            edge_index.append( ( id_map[item_id], id_map[user_id] ) )

items = list(items)
male_users = list(male_users)
female_users = list(female_users)

targets = torch.tensor(targets, dtype=torch.long)
targets = targets[ torch.randperm( targets.size(0) ) ]
edge_index = torch.tensor(edge_index, dtype=torch.long).t()
edge_index = coalesce(edge_index)
x = torch.ones( (id_count, 1), dtype=torch.float )

print(edge_index.max(), x.size() )

data = Data( x=x, edge_index=edge_index, num_nodes=x.size(0) )

male = []
female = []

for i,g in enumerate(targets_gender):
    if g == "Male":
        male.append(i)
    else:
        female.append(i)

male = torch.tensor(male, dtype=torch.long)
female = torch.tensor(female, dtype=torch.long)
val_size = int(0.05*len( targets ))

split_edge = { "train": {"edge": targets[male][val_size:]}, "valid": {"edge": targets[male][:val_size]}, "test":  {"edge": targets[female]} }

for key in split_edge:
    if key == "test":
        neg_users = torch.from_numpy(np.random.choice(female_users, split_edge[key]["edge"].size(0) ,replace=True )).long()
    else:
        neg_users = torch.from_numpy(np.random.choice(male_users, split_edge[key]["edge"].size(0) ,replace=True )).long()
    neg_items = torch.from_numpy(np.random.choice(items, split_edge[key]["edge"].size(0) ,replace=True )).long()
    split_edge[key]["edge_neg"] = torch.cat([ neg_users.unsqueeze(1),  split_edge[key]["edge"][:,1].unsqueeze(1) ],1)

torch.save(data, "data.pt")
torch.save(split_edge, "split_edge.pt")

print( data.edge_index.size(), data.x.size(0) )
print( split_edge["train"]["edge"].size(), split_edge["valid"]["edge"].size(), split_edge["test"]["edge"].size()  )